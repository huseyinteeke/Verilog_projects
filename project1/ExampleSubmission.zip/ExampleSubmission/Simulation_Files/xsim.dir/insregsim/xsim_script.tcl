xsim {insregsim} -autoloadwcfg -runall
