xsim {dataregsim} -autoloadwcfg -runall
