xsim {dmusim} -autoloadwcfg -runall
