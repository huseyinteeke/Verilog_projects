xsim {regfilesim} -autoloadwcfg -runall
