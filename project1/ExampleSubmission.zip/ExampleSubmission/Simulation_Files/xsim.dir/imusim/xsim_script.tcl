xsim {imusim} -autoloadwcfg -runall
