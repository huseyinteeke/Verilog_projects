xsim {alusyssim} -autoloadwcfg -runall
