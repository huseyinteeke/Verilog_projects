xsim {alusim} -autoloadwcfg -runall
