xsim {addregfilesim} -autoloadwcfg -runall
